import React from "react";

export const nameContext = React.createContext();
