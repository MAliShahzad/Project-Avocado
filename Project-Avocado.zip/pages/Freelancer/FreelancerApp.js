import React, { Component } from "react";
import { DrawerScreens } from "./Navigators/DrawerScreens";

export const FreelancerApp = () => {
  return <DrawerScreens />;
};
