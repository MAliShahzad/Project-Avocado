import React, { Component } from "react";
import { StyleSheet, View, Image, Dimensions, ScrollView } from "react-native";
import { Block, Text, theme, Button, Icon, Card } from "galio-framework";
const { width, height } = Dimensions.get("screen");
import { RatingView } from "../../../components/RatingView";
import { TouchableOpacity } from "react-native-gesture-handler";
import { AuthContext } from "../../Auth/Navigators/context";


const DisplayCard = ({
  navigation,
  name,
  stars,
  email,
  description,
  imageLink
}) => (
  <TouchableOpacity
    onPress={() => {
      navigation.navigate("ClientViewsFreelancer", {
        name,
        email,
        description,
        imageLink
      });
    }}
  >
    <Block style={styles.ratingcard}>
      <View style={{ marginHorizontal: 10, marginVertical: 10 }}>
        <Image
          source={require("../../../images/mustafaAsif.jpeg")}
          style={{ height: 40, width: 40, borderRadius: 60 }}
          onError={() => require("../../../images/avocado-logo.png")}
        />
      </View>
      <View style={{ marginHorizontal: 10, marginVertical: 10 }}>
        <Text style={{ marginHorizontal: 10 }}>{name}</Text>
        <RatingView style={{ alignItems: "flex-start" }} stars={stars} />
      </View>
    </Block>
  </TouchableOpacity>
);

export const BrowseFreelancers = ({route, navigation }) => {
  const { getEmail } = React.useContext(AuthContext);
  const myEmail = getEmail();
  const packet = JSON.stringify({message: 'Freelancer List', category: route.params.category})
  //database returns freelancer list based on category
  const freelancerList = [
    {
      name : 'Omer Shakeel',
      stars : 3,
      email : 'omer@hotmail.com',
      description : 'Uni student, computer sciences',
      image: "../../../images/mustafaAsif.jpeg"
    },
    {
      name : 'Mustafa Asif',
      stars : 5,
      email : 'maroof@hotmail.com',
      description : 'Uni student, computer sciences',
      image: "../../../images/mustafaAsif.jpeg"
    },
    {
      name : 'Sabeeh Rahman',
      stars : 4,
      email : 'sabeeh@hotmail.com',
      description : 'Uni student, computer sciences',
      image: "../../../images/mustafaAsif.jpeg"
    },
  ];
  return (
    <ScrollView>
    <View style={styles.container}>
      {freelancerList.map((freelancer) =>  {
        return(<DisplayCard
              name={freelancer.name}
              stars={freelancer.stars}
              email={freelancer.email}
              description={freelancer.description}
              imageLink = {freelancer.image}
              navigation={navigation}
            ></DisplayCard>);
      })}
    </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#558b2f",
    paddingHorizontal: 20,
    alignItems: "flex-start",
    // justifyContent: "flex-start",
    paddingVertical: 50,
    paddingBottom: 330,
    flex: 1,
    width
  },
  pic: {
    flexDirection: "row"
  },
  item: {
    paddingVertical: 10
  },

  ratingcard: {
    backgroundColor: "#f8ffd7",
    borderWidth: 0,
    marginVertical: theme.SIZES.BASE * 0.875,
    justifyContent: "flex-start",
    width: width - theme.SIZES.BASE * 2,
    height: theme.SIZES.BASE * 4,
    alignContent: "center",
    borderRadius: 10,
    flexDirection: "row"
  }
});
