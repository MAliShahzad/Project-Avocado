import * as React from "react";
import { Text, View, ScrollView, TouchableOpacity } from "react-native";
import { Card } from "react-native-elements";
import { AuthContext } from "../../Auth/Navigators/context";

export const CompletedScreen = ({ navigation }) => {
  const { getEmail } = React.useContext(AuthContext);
  const myEmail = getEmail();
  const packet = JSON.stringify({message: 'Completed Task List', nameClient: myEmail})
  //database returns tasklist
  const taskList = [
    {
      title: 'Descriptive Essay', 
      category: 'Cotent Writing',
      description: "Write essay on US History.",
      deadline: "20-1-2019",
      attachment: 'none',
      freelancer: 'Ahmed'
    },
    {
      title: 'Mobile App', 
      category: 'Program Development',
      description: "Develop Mobile Application.",
      deadline: "20-1-2019",
      attachment: 'none',
      freelancer: 'Ali'
    },
    {
      title: 'Research Essay', 
      category: 'Cotent Writing',
      description: "Write a research essay on sexism in Pakistan.",
      deadline: "20-1-2019",
      attachment: 'none',
      freelancer: 'Javed'
    },
  ]
  return (
    <ScrollView>
      <View>
        {taskList.map((task) => {
          return (
            <TouchableOpacity onPress = {() => navigation.navigate("CompletedTask", {taskDetails: task})}>
              <Card title={task.title}>
                <Text style = {{marginBottom: 10}}>
                  {task.description}
                </Text>
              </Card>
            </TouchableOpacity>
          );
        })}
      </View>
    </ScrollView>
  );
};