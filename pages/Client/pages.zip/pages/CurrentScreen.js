import * as React from "react";
import {
  Text,
  View,
  ScrollView,
  Dimensions,
  TouchableOpacity
} from "react-native";
import { Card } from "react-native-elements";
import ProgressBar from "react-native-progress/Bar";
import { AuthContext } from "../../Auth/Navigators/context";

export const CurrentScreen = ({ navigation }) => {
  const { getEmail } = React.useContext(AuthContext);
  const myEmail = getEmail();
  const packet = JSON.stringify({message: 'Current Task List', nameClient: myEmail})
  //database returns tasklist
  const taskList = [
    {
      id: 1,
      title: 'Descriptive Essay', 
      category: 'Cotent Writing',
      description: "Write essay on US History.",
      deadline: "20-1-2019",
      attachment: 'none',
      freelancer: 'none'
    },
    {
      id: 2,
      title: 'Mobile App', 
      category: 'Program Development',
      description: "Develop Mobile Application.",
      deadline: "20-1-2019",
      attachment: 'none',
      freelancer: 'Ali'
    },
    {
      id:3,
      title: 'Research Essay', 
      category: 'Cotent Writing',
      description: "Write a research essay on sexism in Pakistan.",
      deadline: "20-1-2019",
      attachment: 'none',
      freelancer: 'Javed'
    },
  ]
  return (
    <ScrollView>
      <View>
        {taskList.map((task) => {
          return (
            <TouchableOpacity onPress = {() => {
              if(task.freelancer == 'none'){
                navigation.navigate("ViewTaskUnassigned", {taskDetails: task})}
              else{
                navigation.navigate("ViewTask", {taskDetails: task})
              }
            }}>
              <Card title={task.title}>
                <Text style = {{marginBottom: 10}}>
                  {task.description}
                </Text>
                <Text style={{ fontWeight: "bold" }}>
                  Deadline: {task.deadline}
                </Text>
                <ProgressBar
                  color="green"
                  borderRadius={20}
                  progress={0.5}
                  width={Dimensions.get("window").width - 40 - 10}
                  height={15}
                />
              </Card>
            </TouchableOpacity>
          );
        })}
      </View>
    </ScrollView>
  );
};