import React, { Component } from "react";
import {
  View,
  Image,
  StyleSheet,
  Text,
  Button,
  Alert,
  Dimensions
} from "react-native";
import { AuthContext } from "../../Auth/Navigators/context";

//import { Card } from "react-native-elements";

export default function ClientProfile({ navigation }) {
  const { getEmail } = React.useContext(AuthContext);
  const myEmail = getEmail();
  const Description =
    "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore";

  return (
    <View style={styles.container}>
      <View style={styles.imageContainer}>
        <Image
          // resizeMode="contain"
          // style={styles.canvas}
          style={{ flex: 1, width: undefined, height: undefined }}
          source={require("../../../images/mustafaAsif.jpeg")}
        />
      </View>
      <View style={styles.buttonAndText}>
        <View style={styles.textContainer}>
          <Text style={styles.bigText}>Mustafa Asif</Text>
          <Text>mustafaasif1@hotmail.com</Text>
        </View>
        <View style={styles.buttonDiv}>
          <Button
            title="Edit"
            color="green"
            onPress={() => navigation.navigate("EditProfile")}
          />
        </View>
      </View>
      <View style={styles.lowerPortion}>
        <View style={styles.name}>
          <Text style={styles.bigText}>Client</Text>
          <Button
            title="Edit"
            color="brown"
            onPress={() => navigation.navigate("EditDescription")}
          />
        </View>
        <View style={{ padding: 20 }}>
          <Text>Who am I?</Text>
          <Text>{Description}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center"
  },
  canvas: {
    height: 200,
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    right: 0
  },
  imageContainer: {
    backgroundColor: "white",
    width: Dimensions.get("window").width,
    height: 250
  },
  bigText: {
    fontWeight: "bold",
    fontSize: 20
  },
  textContainer: {
    padding: 20,
    flex: 2
  },
  buttonAndText: {
    flexDirection: "row"
  },
  buttonDiv: {
    justifyContent: "center",
    alignItems: "center",
    flex: 1
  },
  lowerPortion: {
    backgroundColor: "white",
    // flex: 1,
    height: 400,
    // alignItems: "center",
    // justifyContent: "center",
    width: Dimensions.get("window").width,
    borderTopColor: "green",
    borderColor: "white",
    borderWidth: 1
  },
  name: {
    padding: 20,
    flexDirection: "row",
    justifyContent: "space-between"
  },
  ex: {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").heigth
  },
  textstyle: {
    width: Dimensions.get("window").width,
    padding: 20
  }
});
