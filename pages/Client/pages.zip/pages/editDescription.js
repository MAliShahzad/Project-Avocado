import React, { useState } from "react";
import {
  StyleSheet,
  Button,
  TextInput,
  View,
  Text,
  Alert,
  Dimensions
} from "react-native";
import { AuthContext } from "../../Auth/Navigators/context";

export default function EditDescription({ navigation }) {
  const [Description, setDescription] = useState("");
  const { getEmail } = React.useContext(AuthContext);
  const myEmail = getEmail();
  
  return (
    <View style={styles.container}>
      <Text style={styles.bigText}>Edit your Description</Text>
      <TextInput
        style={styles.input}
        multiline={true}
        placeholder="Description"
        onChangeText={val => setDescription(val)}
      />
      <View style={{ padding: 10 }}>
        <Button
          title="Submit"
          color="green"
          onPress={() => navigation.goBack({ post: Description })}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20
  },
  bigText: {
    fontWeight: "bold",
    fontSize: 20
  },
  input: {
    borderWidth: 1,
    borderColor: "#777",
    padding: 8,
    margin: 10,
    width: Dimensions.get("window").width - 40 - 10
  }
});
