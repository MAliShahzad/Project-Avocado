import React, { useState } from "react";
import {
  StyleSheet,
  Button,
  TextInput,
  View,
  Text,
  Alert,
  ScrollView,
  Dimensions
} from "react-native";
import { AuthContext } from "../../Auth/Navigators/context";

export default function EditProfile({ navigation }) {
  const [email, setEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [addAttachment, setAddAttachment] = useState("");
  const { getEmail } = React.useContext(AuthContext);
  const myEmail = getEmail();

  return (
    <ScrollView>
      <View style={styles.container}>
        <Text>Change Email?</Text>
        <TextInput
          style={styles.input}
          placeholder="mustafaasif1@hotmail.com"
          onChangeText={val => setEmail(val)}
        />
        <Text>Change Password?</Text>
        <TextInput
          secureTextEntry={true}
          style={styles.input}
          placeholder="********"
          onChangeText={val => setNewPassword(val)}
        />
        <Text>Re-Enter Password?</Text>
        <TextInput
          secureTextEntry={true}
          style={styles.input}
          placeholder="********"
          onChangeText={val => setConfirmPassword(val)}
        />
        <Text>Change Profile Picture</Text>
        <TextInput
          style={styles.input}
          placeholder="Old Picture"
          onChangeText={val => setAddAttachment(val)}
        />
        <View style={{ padding: 10 }}>
          <Button
            title="Submit"
            color="green"
            onPress={() => navigation.goBack()}
          />
        </View>
        <Text>Email: {email}</Text>
        <Text>Password: {newPassword}</Text>
        <Text>Confirm Password: {confirmPassword}</Text>
        <Text>Attachment: {addAttachment}</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20
  },
  input: {
    borderWidth: 1,
    borderColor: "#777",
    padding: 8,
    margin: 10,
    width: Dimensions.get("window").width - 60
  }
});
