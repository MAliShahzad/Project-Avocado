import React, { useState } from "react";
import {
  StyleSheet,
  Button,
  TextInput,
  View,
  Text,
  Alert,
  Dimensions,
  ScrollView,
  Picker
} from "react-native";
import DatePicker from 'react-native-datepicker'
import { AuthContext } from "../../Auth/Navigators/context";

export const NewTask = ({navigation}) => {
  const { getEmail } = React.useContext(AuthContext);
  const [title, settitle] = useState("");
  const [category, setcategory] = useState("");
  const [description, setdescription] = useState("");
  const [addAttachment, setAddAttachment] = useState("");
  const [deadline, setDeadline] = useState("");
  const myEmail = getEmail();
  const submitHandler = () => {
    const packet = JSON.stringify({message: 'New task', nameClient: myEmail, jobTitle: title, jobCategory: category, jobDescription: description, jobAttachment: addAttachment, jobDeadline: deadline});
    //receive message of 'Valid' from db
    const msg = 'Valid'
    if(msg == 'Valid'){
      Alert.alert(
                  "Congratulations",
                  "A new task has been added.",
                  [{ text: "OK", onPress: () => console.log("OK Pressed") }],
                  { cancelable: false }
      );
   }
   else{
    Alert.alert(
                  "Error",
                  "Some of the details are invalid.",
                  [{ text: "OK", onPress: () => console.log("OK Pressed") }],
                  { cancelable: false }
      );
   }
  }
  return (
    <ScrollView>
      <View style={styles.container}>
        <Text>{myEmail}</Text>
        <Text>Title</Text>
        <TextInput
          style={styles.input}
          placeholder="Add title"
          onChangeText={(val) => settitle(val)}
        />
        <Text>Category</Text>
        <View style= {{margin: 10, justifyContent: 'center', marginLeft: 17, borderWidth: 1, width: 335, height: 40}}>
          <Picker
            style = {{marginLeft: 78, marginRight: 78,transform: [{ scaleX: 0.85 }, { scaleY: 0.85 },]}}
            selectedValue = {category}
            onValueChange = {(itemValue, itemIndex) => setcategory(itemValue)}>
            <Picker.Item label="Select Category" value = ""/>
            <Picker.Item label="Content Writing" value = "contentWriting"/>
            <Picker.Item label="Computer Science" value = "computerScience"/>
          </Picker>
        </View>
        <Text>Description</Text>
        <TextInput
          style={styles.input}
          placeholder="Add description"
          onChangeText={(val) => setdescription(val)}
        />
        <Text>Attachment</Text>
        <TextInput
          style={styles.input}
          placeholder="Upload File"
          onChangeText={(val) => setAddAttachment(val)}
        />
        <Text>Deadline</Text>
        <DatePicker
          style ={{padding:8, margin: 10, width: 350}}
          date = {deadline}
          mode = "date"
          placeholder = "Select Date"
          showIcon = {false}
           
          onDateChange={(date) => {setDeadline(date)}}
        />
        <View style={{ padding: 10 }}>
          <Button
            title="Submit"
            color="green"
            onPress={() => {
              submitHandler()
              //navigation.pop();
            }}
          />
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: "#777",
    padding: 5.5,
    margin: 10,
    marginLeft: 17,
    width: 335,
    textAlign: 'center'
  },
});
